#pragma once
#include <vector>

using namespace std;

vector<bool> MixVectors(vector<bool> a, vector<bool> b);

int newOnesInVector(vector<bool>a, vector<bool> b);