#pragma once
class Room
{
public:
	int id, capacity;
	Room(int id, int capacity = 0);
};

