#include "Room.h"

Room::Room(int id, int capacity)
{
	this->id = id;
	this->capacity = 0;
}
